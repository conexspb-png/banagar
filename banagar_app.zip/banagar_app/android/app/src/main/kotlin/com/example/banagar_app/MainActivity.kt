package com.example.banagar_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
