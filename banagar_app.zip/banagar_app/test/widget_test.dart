import 'package:flutter_test/flutter_test.dart';

void main() {

  test(
    'BanaGar AI OS test',
        () {

      expect(true, true);

    },
  );

}