
import 'package:flutter/material.dart';


class ProductCenter extends StatelessWidget {

  const ProductCenter({super.key});


  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: const Text(
          "مرکز محصولات بناگر",
        ),

        backgroundColor: Colors.orange,

      ),


      body: ListView(

        padding:
        const EdgeInsets.all(20),


        children: [


          productCard(

            "🏠 Super Box",

            "ساختمان مدولار پیش ساخته بناگر\n"
                "نصب سریع، توسعه پذیر و صنعتی",

            Colors.orange,

          ),



          productCard(

            "🏡 Swiss Villa",

            "ویلاهای A Frame سوئیسی\n"
                "مدل‌های 45، 60، 80 و 120 متر",

            Colors.green,

          ),



          productCard(

            "🏢 ساختمان پیش ساخته",

            "ساختمان‌های اداری، صنعتی و کارگاهی\n"
                "راهکار سریع ساخت",

            Colors.blue,

          ),



          productCard(

            "🚧 کانکس بناگر",

            "کانکس‌های تخصصی\n"
                "کارگاهی، مدیریتی و تجهیز کارگاه",

            Colors.grey,

          ),



        ],

      ),

    );

  }



  Widget productCard(

      String title,

      String description,

      Color color

      ){


    return Card(

      elevation:6,


      margin:
      const EdgeInsets.only(bottom:20),


      shape:
      RoundedRectangleBorder(

        borderRadius:
        BorderRadius.circular(20),

      ),


      child: Container(

        padding:
        const EdgeInsets.all(20),


        child: Column(

          crossAxisAlignment:
          CrossAxisAlignment.start,


          children: [


            Container(

              width:60,

              height:60,

              decoration:
              BoxDecoration(

                color:color,

                borderRadius:
                BorderRadius.circular(15),

              ),


              child:
              const Icon(

                Icons.home_work,

                color:Colors.white,

                size:32,

              ),

            ),



            const SizedBox(height:15),



            Text(

              title,

              style:
              const TextStyle(

                fontSize:22,

                fontWeight:
                FontWeight.bold,

              ),

            ),



            const SizedBox(height:10),



            Text(

              description,

              style:
              const TextStyle(

                fontSize:16,

              ),

            ),



            const SizedBox(height:15),



            ElevatedButton(

              onPressed: () {},

              child:
              const Text(
                "مشاهده جزئیات",
              ),

            ),


          ],

        ),

      ),

    );

  }


}