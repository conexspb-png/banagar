import 'package:flutter/material.dart';

class Dashboard extends StatelessWidget {
  const Dashboard({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor: const Color(0xfff5f5f5),

      appBar: AppBar(
        backgroundColor: Colors.orange,
        title: const Text(
          "BanaGar AI OS",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),


      body: Padding(
        padding: const EdgeInsets.all(20),

        child: Column(

          crossAxisAlignment: CrossAxisAlignment.start,

          children: [

            const Text(
              "سلام هادی راد 👋",
              style: TextStyle(
                fontSize:26,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height:8),


            const Text(
              "سیستم هوشمند مدیریت شرکت بناگر",
              style: TextStyle(
                fontSize:16,
              ),
            ),


            const SizedBox(height:30),


            Expanded(

              child: GridView.count(

                crossAxisCount:2,

                crossAxisSpacing:15,

                mainAxisSpacing:15,


                children: [


                  menuCard(
                    "🏗 محصولات بناگر",
                    "Super Box\nویلا\nکانکس",
                  ),


                  menuCard(
                    "🤖 BanaGar AI",
                    "دستیار هوشمند\nتولید محتوا",
                  ),


                  menuCard(
                    "📁 پروژه‌ها",
                    "مدیریت پروژه\nگزارش‌ها",
                  ),


                  menuCard(
                    "📱 Content AI",
                    "تولید محتوای\nاینستاگرام",
                  ),


                ],

              ),
            )

          ],
        ),
      ),

    );
  }



  Widget menuCard(String title,String text){

    return Card(

      elevation:5,

      shape: RoundedRectangleBorder(

        borderRadius:
        BorderRadius.circular(20),

      ),


      child: Padding(

        padding:
        const EdgeInsets.all(15),

        child: Column(

          mainAxisAlignment:
          MainAxisAlignment.center,


          children:[

            Text(

              title,

              textAlign:
              TextAlign.center,

              style:
              const TextStyle(

                fontSize:18,

                fontWeight:
                FontWeight.bold,

              ),

            ),


            const SizedBox(height:15),


            Text(

              text,

              textAlign:
              TextAlign.center,

            ),

          ],

        ),

      ),

    );

  }

}