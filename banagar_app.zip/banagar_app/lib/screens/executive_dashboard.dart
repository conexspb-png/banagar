import 'package:flutter/material.dart';
import '../widgets/sidebar_menu.dart';


class ExecutiveDashboard extends StatelessWidget {

  const ExecutiveDashboard({super.key});


  @override
  Widget build(BuildContext context) {

    return Scaffold(

      drawer: const SidebarMenu(),


      appBar: AppBar(

        title: const Text(
          "BanaGar AI OS",
        ),

        backgroundColor: Colors.orange,

      ),


      body: Padding(

        padding: const EdgeInsets.all(20),

        child: Column(

          crossAxisAlignment:
          CrossAxisAlignment.start,


          children: [


            const Text(

              "سلام هادی راد 👋",

              style: TextStyle(

                fontSize:26,

                fontWeight:
                FontWeight.bold,

              ),

            ),


            const SizedBox(height:10),


            const Text(

              "داشبورد هوشمند مدیریت بناگر",

              style: TextStyle(

                fontSize:16,

              ),

            ),


            const SizedBox(height:30),



            Expanded(

              child: GridView.count(

                crossAxisCount:2,

                mainAxisSpacing:15,

                crossAxisSpacing:15,


                children: [


                  dashboardCard(
                    "🏗 محصولات",
                    "Super Box\nویلا\nکانکس",
                  ),


                  dashboardCard(
                    "🤖 BanaGar AI",
                    "دستیار هوشمند",
                  ),


                  dashboardCard(
                    "📁 پروژه‌ها",
                    "مدیریت پروژه",
                  ),


                  dashboardCard(
                    "📱 Content AI",
                    "تولید محتوا",
                  ),


                ],

              ),
            )

          ],

        ),

      ),

    );

  }



  Widget dashboardCard(
      String title,
      String subtitle
      ){

    return Card(

      elevation:5,

      child: Center(

        child: Column(

          mainAxisAlignment:
          MainAxisAlignment.center,


          children: [


            Text(

              title,

              style:
              const TextStyle(

                fontSize:18,

                fontWeight:
                FontWeight.bold,

              ),

            ),


            const SizedBox(height:10),


            Text(subtitle),

          ],

        ),

      ),

    );

  }


}