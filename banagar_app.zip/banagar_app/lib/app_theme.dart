import 'package:flutter/material.dart';


class ProductsPage extends StatelessWidget {

  const ProductsPage({super.key});


  @override
  Widget build(BuildContext context){

    return Scaffold(

      appBar: AppBar(
        title:
        const Text("محصولات بناگر"),
      ),


      body:

      ListView(

        padding:
        const EdgeInsets.all(20),

        children:[


          productCard(
            "🏠 Super Box",
            "ساختمان مدولار پیش ساخته بناگر",
          ),


          productCard(
            "🏡 Swiss Villa",
            "ویلاهای A Frame سوئیسی",
          ),


          productCard(
            "🏢 ساختمان پیش ساخته",
            "راهکارهای سریع ساخت صنعتی",
          ),


          productCard(
            "🚧 کانکس",
            "کانکس‌های تخصصی و کارگاهی",
          ),


        ],

      ),

    );

  }


  Widget productCard(
      String title,
      String description
      ){

    return Card(

      child:
      ListTile(

        title:
        Text(
          title,
          style:
          const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize:18,
          ),
        ),

        subtitle:
        Text(description),

        trailing:
        const Icon(
          Icons.arrow_forward_ios,
        ),

      ),

    );

  }

}