import 'package:flutter/material.dart';
class SidebarMenu extends StatelessWidget {

  const SidebarMenu({super.key});
  @override
  Widget build(BuildContext context) {

    return Drawer(

      child: ListView(

        padding: EdgeInsets.zero,

        children: [

          DrawerHeader(

            decoration: const BoxDecoration(
              color: Colors.orange,
            ),

            child: const Column(

              crossAxisAlignment:
              CrossAxisAlignment.start,

              children: [

                Text(
                  "BanaGar AI OS",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                SizedBox(height: 10),

                Text(
                  "Enterprise Business Platform",
                  style: TextStyle(
                    color: Colors.white70,
                  ),
                ),

              ],

            ),
          ),


          _item(
            Icons.dashboard,
            "داشبورد",
          ),

          _item(
            Icons.home_work,
            "محصولات بناگر",
          ),

          _item(
            Icons.smart_toy,
            "BanaGar AI",
          ),

          _item(
            Icons.content_copy,
            "Content Engine",
          ),

          _item(
            Icons.folder,
            "پروژه‌ها",
          ),

          _item(
            Icons.people,
            "CRM مشتریان",
          ),

          _item(
            Icons.analytics,
            "گزارش‌ها",
          ),

          _item(
            Icons.settings,
            "تنظیمات",
          ),

        ],
      ),
    );
  }


  Widget _item(
      IconData icon,
      String title
      ){

    return ListTile(

      leading: Icon(icon),

      title: Text(
        title,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
        ),
      ),

      onTap: () {},

    );
  }

}