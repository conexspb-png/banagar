import 'package:flutter/material.dart';
import 'screens/executive_dashboard.dart';


void main() {

  runApp(
      const BanaGarApp()
  );

}


class BanaGarApp extends StatelessWidget {

  const BanaGarApp({super.key});


  @override
  Widget build(BuildContext context) {

    return MaterialApp(

      debugShowCheckedModeBanner: false,

      title: "BanaGar AI OS",

      theme: ThemeData(

        primarySwatch: Colors.orange,

      ),

      home: const ExecutiveDashboard(),

    );

  }

}